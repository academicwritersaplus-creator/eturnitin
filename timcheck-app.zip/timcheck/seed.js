'use strict';
/*
 * Loads sources into the comparison collection.
 *   npm run seed                      -> loads sample-sources.json (also done automatically on first start)
 *   npm run add-sources -- ./folder   -> loads every .txt, .pdf and .docx file in a folder
 * Re-running is safe: a source with the same title is updated, not duplicated.
 */
const fs = require('fs');
const path = require('path');
const { pool } = require('./db');
const migrate = require('./migrate');
const { indexSource, tokenize } = require('./similarity');
const { extractText, detectType } = require('./extract');

async function upsertSource({ title, author, origin, body }) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const words = tokenize(body).length;
    const { rows } = await client.query(
      `INSERT INTO sources (title, author, origin, body, word_count) VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (title) DO UPDATE SET author = EXCLUDED.author, origin = EXCLUDED.origin,
         body = EXCLUDED.body, word_count = EXCLUDED.word_count
       RETURNING id`, [title.slice(0, 300), author || null, origin || null, body, words]);
    const n = await indexSource(client, rows[0].id, body);
    await client.query('COMMIT');
    return { id: rows[0].id, shingles: n };
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

async function fromFolder(dir) {
  const files = fs.readdirSync(dir).filter(f => /\.(txt|pdf|docx)$/i.test(f));
  for (const f of files) {
    const buf = fs.readFileSync(path.join(dir, f));
    const type = /\.txt$/i.test(f) ? 'text' : detectType(buf, f);
    if (!type) { console.warn(`skip ${f}: not a valid file`); continue; }
    try {
      const body = await extractText(buf, type);
      const r = await upsertSource({ title: f.replace(/\.[^.]+$/, ''), author: null, origin: `Imported file: ${f}`, body });
      console.log(`added "${f}" (source #${r.id}, ${r.shingles} shingles)`);
    } catch (e) { console.warn(`skip ${f}: ${e.message}`); }
  }
}

async function seedSamples() {
  const samples = JSON.parse(fs.readFileSync(path.join(__dirname, 'sample-sources.json'), 'utf8'));
  for (const s of samples) {
    const r = await upsertSource(s);
    console.log(`source #${r.id}: ${s.title}`);
  }
}

async function main() {
  await migrate();
  const dir = process.argv[2];
  if (dir) await fromFolder(dir);
  else await seedSamples();
  const { rows } = await pool.query('SELECT count(*)::int AS n FROM sources');
  console.log(`Comparison collection now has ${rows[0].n} sources.`);
}

if (require.main === module) {
  main().then(() => pool.end()).catch(e => { console.error(e.message); process.exit(1); });
}

module.exports = { upsertSource, seedSamples };
