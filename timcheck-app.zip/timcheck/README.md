# TimCheck

TimCheck is an **educational demonstration** of a similarity (plagiarism) checker. It shows how a checker reads a document, finds matching passages, calculates a percentage, and makes a report. It also teaches how fake checker websites and edited reports mislead students.

> **TimCheck is not connected to Turnitin or any other commercial service.** It compares text only with its own small sample collection. Every report carries the watermark **"TimCheck • EDUCATIONAL DEMO • NOT A TURNITIN REPORT"**. Never present a TimCheck report as a Turnitin report or as proof that work is original.

All files are in **one folder, with no sub-folders**. This makes it easy to upload to GitHub.

---

## 1. Put it online with Render (about 10 minutes)

You need a free **GitHub** account and a free **Render** account. Use a computer.

### Step 1: Upload the files to GitHub
1. Unzip `timcheck.zip` on your computer. You get a folder called `timcheck`.
2. Go to **github.com/new**. Name the repository `timcheck`. Leave all other options off. Click **Create repository**.
3. Click **uploading an existing file**.
4. Click **choose your files**. Open the `timcheck` folder, select **all** files (Ctrl+A on Windows, Cmd+A on Mac), and click **Open**.
5. Wait until every file shows in the list. Click **Commit changes**.

Check: the repository should show `server.js`, `package.json` and `render.yaml`.

### Step 2: Create the website on Render
1. Go to **render.com** and sign in with GitHub.
2. Click **New** → **Blueprint**.
3. Connect your GitHub account if asked, then choose the `timcheck` repository.
4. Render reads `render.yaml` and shows two items: **timcheck** (the website) and **timcheck-db** (the database).
5. It asks for **ADMIN_EMAILS**. Type your own email address.
6. Click **Apply** (or **Deploy Blueprint**).
7. Wait 3–5 minutes. When **timcheck** says **Live**, click its address (it ends in `.onrender.com`).

That is all. The database tables and the sample collection are created automatically the first time the site starts.

### Step 3: Try it
1. Click **Create account**. Use the same email you typed in ADMIN_EMAILS. You become the admin.
2. Click **Check a document** and paste some text, or upload a PDF or Word file.
3. Open the report and download the PDF.

### Free plan limits
- The site sleeps after 15 minutes with no visitors. The next visit takes about one minute to load.
- Render deletes free databases after 30 days unless you upgrade the database (about $7 a month).
- Uploaded original files are removed when the site restarts. Reports still work, because the text is saved in the database. To keep the original files, see section 5.

### If it does not work
- Open **timcheck** on Render and click **Logs**. Copy the red error lines and send them for help.
- "Blueprint" not available? Create the parts by hand: **New → PostgreSQL** (Free), then **New → Web Service** with this repository, build command `npm install`, start command `npm start`, and one environment variable `DATABASE_URL` = the database's **Internal Database URL**. Add `ADMIN_EMAILS` too.

---

## 2. What it does

| Feature | How it works |
|---|---|
| Accounts | Register with full name, email and password (8+ characters, a letter and a number). Passwords are stored as bcrypt hashes. |
| Dashboard | Counts by status, average similarity, recent submissions. |
| Private history | Each user sees only their own documents. Others get "not found", even if they guess an address. |
| Submit | PDF, Word (.docx), or pasted text. 10 MB limit. The file type is checked from its content, not only its name. |
| Background processing | Status moves from **pending** to **processing** to **completed** or **failed** (with a clear reason). |
| Similarity checker | Real text matching against the sample collection. The same text always gives the same result. |
| Report | Watermark, highlighted passages, numbered sources, percentage per source, reference, date and time. |
| PDF report | Watermark on every page. Footer with the reference and a verification link. |
| Verify page | Anyone can enter a report reference and see the true stored numbers. This shows how an edited PDF can be caught. |
| History and search | Search by title or reference. Filter by status and date. 20 per page. |
| Admin page | All submissions (title, owner, date, status, %), with a filter by user. Admins cannot read other people's text. |
| Learn page | Fake checker sites, edited PDFs, how to tell a genuine report, and why a percentage is not proof of plagiarism. |

### How the percentage is calculated
1. The text is split into words. Capital letters and punctuation are ignored.
2. Every run of 5 words is turned into a code (a "hash").
3. All codes are looked up in the database in one fast query.
4. Every hit is checked word by word, so there are no false matches.
5. Hits that continue in the same order become one highlighted passage.
6. Each word counts only once, even if two sources match it.
7. **Similarity = matched words ÷ total words × 100.**

---

## 3. Honest limits
- The sample collection has only 14 short texts. Most real writing will show 0%.
- Only exact runs of 5 or more words are found. Rewording is not detected.
- Quotes and reference lists are not removed before checking.
- Scanned PDFs (pictures of pages) cannot be read. Old .doc files are not supported.
- There is no "forgot password" email yet.
- The S3/R2 storage option is written but was not tested with a real bucket.

---

## 4. Settings (environment variables)

On Render, only `DATABASE_URL` is required. The rest have safe defaults.

| Name | Default | What it does |
|---|---|---|
| `DATABASE_URL` | local database | PostgreSQL address. Render's Blueprint fills it in. |
| `ADMIN_EMAILS` | none | Emails that become admins (separate with commas). |
| `SESSION_SECRET` | created automatically | Keeps logins secure. If empty, a random one is made and saved in the database. |
| `APP_URL` | Render's address | Public address printed on PDF reports. |
| `DATABASE_SSL` | automatic | `true` or `false` to force it. Normally not needed. |
| `MAX_UPLOAD_MB` | `10` | Largest file allowed. |
| `UPLOADS_PER_HOUR` | `120` | Uploads per user per hour. |
| `MAX_WORDS_CHECKED` | `60000` | Words checked per document. |
| `WORKER_CONCURRENCY` | `2` | Documents processed at the same time. |
| `REPORT_TIMEZONE` | `UTC` | Time zone on PDF reports, for example `America/New_York`. |
| `STORAGE_DRIVER` | `local` | `local` or `s3`. See section 5. |

---

## 5. Keeping uploaded files (optional)

To keep original files after restarts, use a free **Cloudflare R2** bucket. Keep the bucket private. Add these settings on Render:

```
STORAGE_DRIVER=s3
S3_BUCKET=timcheck-uploads
S3_REGION=auto
S3_ENDPOINT=https://<your-account-id>.r2.cloudflarestorage.com
S3_ACCESS_KEY_ID=...
S3_SECRET_ACCESS_KEY=...
```

---

## 6. Run it on your own computer (optional)

You need **Node.js 22** and **PostgreSQL**.

```bash
cd timcheck
npm install
psql -U postgres -c "CREATE USER timcheck WITH PASSWORD 'timcheck';"
psql -U postgres -c "CREATE DATABASE timcheck OWNER timcheck;"
npm start
```

Open http://localhost:3000. To change settings, copy `.env.example` to `.env` and edit it.

---

## 7. Handling 1,000+ documents

- Every record is in PostgreSQL, with indexes on owner, date, status, reference and title.
- History pages load 20 records at a time.
- Uploads are queued and processed in the background. Several workers can share the queue safely (`FOR UPDATE SKIP LOCKED`).
- A job that gets stuck (for example after a crash) goes back to the queue after 10 minutes, up to 3 tries.
- **Tested:** 1,200 documents were sent through the real website. All 1,200 completed, none failed. With 1,200+ stored, every page, search and filter answered in under 10 ms.

Why not store everything in the browser? Browser storage holds only about 5–10 MB, lives on one device, is lost when the browser is cleared, and cannot keep users apart safely. A server database fixes all of these.

---

## 8. Testing checklist

Automated (all passed for this version):

```bash
npm start                              # in one window
npm test                               # in another: 40 checks
UPLOADS_PER_HOUR=5000 npm start        # restart with a higher limit, then:
npm run load-test -- 1200              # 1,200 documents
```

`npm test` checks: password rules, register, duplicate email, login, logout, wrong password, CSRF protection, pasted text, PDF, Word, correct sources matched, highlights in the right place, same result twice, fake PDF rejected, .doc message, short text rejected, size limit, PDF report download, verify page, users cannot see each other's documents, admin protection, search, filters, delete.

Also checked for this version:
- [x] Starts on an empty database and loads the samples by itself
- [x] Code files, settings and uploads cannot be opened from a browser
- [x] Logins still work after a restart
- [x] PDF report uses the fonts in the main folder
- [x] Report page shows highlights and watermark in the browser

Check on your live site:
- [ ] Register, log in, log out
- [ ] Upload a PDF and a Word file from your phone
- [ ] Download and print the PDF report
- [ ] Enter the report reference on the Verify page
- [ ] Log in as a second user and confirm you cannot see the first user's documents

---

## 9. Files

| File | What it is |
|---|---|
| `server.js` | Starts the website |
| `config.js`, `db.js`, `migrate.js`, `schema.sql` | Settings and database |
| `seed.js`, `sample-sources.json` | The sample collection |
| `similarity.js` | The matching engine |
| `extract.js` | Reads PDF and Word files |
| `worker.js` | Background processing |
| `storage.js` | Saves uploaded files |
| `report-pdf.js`, `DejaVuSans*.ttf`, `LICENSE-DejaVu.txt` | PDF reports and their fonts (free licence) |
| `middleware.js`, `routes-*.js` | Login checks and website addresses |
| `index.html`, `styles.css`, `app.js`, `favicon.svg` | The pages people see |
| `render.yaml` | One-click Render setup |
| `test-*.js`, `test-*.pdf`, `test-sample.docx` | Tests and test files |
