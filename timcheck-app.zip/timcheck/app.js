'use strict';
/* TimCheck front end: a small single-page app with hash routes. */

const state = { user: null, loaded: false };
const main = document.getElementById('main');
const MAX_UPLOAD_MB = 10;
const WATERMARK = 'TimCheck • EDUCATIONAL DEMO • NOT A TURNITIN REPORT';

// ------------------------------------------------------------ helpers
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtDate = d => d ? new Date(d).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '—';
const fmtDay = d => d ? new Date(d).toLocaleDateString(undefined, { dateStyle: 'medium' }) : '—';
const pct = v => (v === null || v === undefined) ? '—' : `${Number(v).toFixed(1)}%`;
const statusBadge = s => `<span class="status ${esc(s)}">${esc(s[0].toUpperCase() + s.slice(1))}</span>`;
const sizeLabel = b => b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`;

async function api(path, opts = {}) {
  const headers = { 'X-Requested-With': 'TimCheck', ...(opts.headers || {}) };
  let body = opts.body;
  if (body && !(body instanceof FormData)) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(body); }
  const res = await fetch('/api' + path, { method: opts.method || 'GET', headers, body, credentials: 'same-origin' });
  let data = null;
  try { data = await res.json(); } catch { /* no body */ }
  if (!res.ok) {
    const err = new Error((data && data.error) || `Request failed (${res.status})`);
    err.status = res.status; err.data = data;
    if (res.status === 401 && state.user) { state.user = null; renderNav(); go('#/login'); }
    throw err;
  }
  return data;
}

function toast(msg, isError) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.className = 'toast show' + (isError ? ' error' : '');
  clearTimeout(toast.timer); toast.timer = setTimeout(() => { t.className = 'toast'; }, 3500);
}

function go(hash) { if (location.hash === hash) render(); else location.hash = hash; }

function setTitle(t) { document.title = t ? `${t} — TimCheck` : 'TimCheck — similarity checking, explained'; }

// ------------------------------------------------------------ nav
function renderNav() {
  const nav = document.getElementById('nav');
  const links = state.user
    ? [['#/dashboard', 'Dashboard'], ['#/submit', 'Check a document'], ['#/documents', 'My documents'], ['#/learn', 'Learn'], ['#/verify', 'Verify']]
      .concat(state.user.role === 'admin' ? [['#/admin', 'Admin']] : [])
    : [['#/learn', 'Learn'], ['#/verify', 'Verify a report'], ['#/login', 'Log in'], ['#/register', 'Create account']];
  nav.innerHTML = links.map(([h, t]) => `<a href="${h}">${t}</a>`).join('')
    + (state.user ? `<span class="who">${esc(state.user.fullName)}</span><button class="btn-sm" id="logoutBtn">Log out</button>` : '');
  markNav();
  const lb = document.getElementById('logoutBtn');
  if (lb) lb.onclick = async () => {
    await api('/auth/logout', { method: 'POST' }).catch(() => {});
    state.user = null; renderNav(); toast('You are logged out.'); go('#/');
  };
}
function markNav() {
  const base = '#/' + (location.hash.slice(2).split('/')[0] || '');
  document.querySelectorAll('#nav a').forEach(a => { if (a.getAttribute('href') === base) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
}
document.getElementById('menuBtn').onclick = e => {
  const nav = document.getElementById('nav');
  const open = nav.classList.toggle('open');
  e.currentTarget.setAttribute('aria-expanded', open);
};

// ------------------------------------------------------------ router
let pollTimer = null;
const routes = {
  '': landing, login: loginPage, register: registerPage, dashboard: dashboard, submit: submitPage,
  documents: documentsPage, report: reportPage, learn: learnPage, verify: verifyPage, sources: sourcesPage, admin: adminPage,
};
const protectedRoutes = ['dashboard', 'submit', 'documents', 'report', 'admin'];

async function render() {
  clearTimeout(pollTimer);
  document.getElementById('nav').classList.remove('open');
  document.getElementById('menuBtn').setAttribute('aria-expanded', 'false');
  const [path, query] = location.hash.slice(1).split('?');
  const parts = path.replace(/^\//, '').split('/');
  const name = parts[0] || '';
  const view = routes[name];
  if (!view) { main.innerHTML = '<div class="empty"><h1>Page not found</h1><p><a href="#/">Go to the home page</a></p></div>'; return; }
  if (protectedRoutes.includes(name) && !state.user) { sessionStorage.setItem('afterLogin', location.hash); go('#/login'); return; }
  if ((name === 'login' || name === 'register') && state.user) { go('#/dashboard'); return; }
  markNav();
  main.innerHTML = '';
  try {
    await view(parts.slice(1), new URLSearchParams(query || ''));
  } catch (e) {
    main.innerHTML = `<div class="form-error">${esc(e.message)}</div>`;
  }
  if (!render.first) main.focus({ preventScroll: true });
  render.first = false;
  window.scrollTo(0, 0);
}
render.first = true;

window.addEventListener('hashchange', render);
(async function init() {
  try { state.user = (await api('/auth/me')).user; } catch { state.user = null; }
  renderNav();
  render();
})();

// ------------------------------------------------------------ landing
function landing() {
  setTitle('');
  main.innerHTML = `
  <section class="hero">
    <div>
      <h1>See how a similarity checker reads your writing.</h1>
      <p class="lead">TimCheck compares a document with its own collection of sample texts, highlights the passages that match, and explains what the number does and does not mean.</p>
      <div class="row">
        ${state.user ? '<a class="btn btn-primary" href="#/submit">Check a document</a>' : '<a class="btn btn-primary" href="#/register">Create a free account</a>'}
        <a class="btn" href="#/learn">Learn how it works</a>
      </div>
    </div>
    <figure class="specimen" aria-label="Example of a highlighted report">
      <div class="specimen-head">
        <div><strong>Sample essay paragraph</strong><div class="small muted">66 words checked</div></div>
        <div class="specimen-score" id="specScore">0%</div>
      </div>
      <p>In my essay I argue that <mark class="m c0">hand hygiene remains the single most effective measure for preventing healthcare-associated infections in hospitals<sup>1</sup></mark> and care homes. My own view is that managers should make dispensers easier to reach. Also, <mark class="m c1">the water cycle describes the continuous movement of water between the oceans, the atmosphere, and the land<sup>2</sup></mark>, which is a separate point I should cite.</p>
      <figcaption class="specimen-legend">
        <span class="c0"><i class="swatch"></i>Hand Hygiene and the Prevention of Healthcare-Associated Infections</span>
        <span class="c1"><i class="swatch"></i>The Water Cycle</span>
      </figcaption>
    </figure>
  </section>

  <section class="three">
    <div><h3>Upload or paste</h3><p>Send a PDF or Word file, or paste text. Each submission is saved to your private history with its own report reference.</p></div>
    <div><h3>Real text matching</h3><p>Runs of five or more identical words are found and joined into passages. The same text always gives the same result.</p></div>
    <div><h3>Watermarked reports</h3><p>Every report says clearly that it is an educational demonstration and can be checked on the verification page.</p></div>
  </section>

  <section class="honest" style="margin-top:48px">
    <h2>What TimCheck is not</h2>
    <p>TimCheck is not connected to Turnitin or any commercial database. It only knows the ${'<a href="#/sources">sample collection</a>'} listed on this site. A TimCheck report must never be presented as a Turnitin report or as proof that work is original.</p>
  </section>`;
  const fig = main.querySelector('.specimen');
  const score = document.getElementById('specScore');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  requestAnimationFrame(() => setTimeout(() => {
    fig.classList.add('lit');
    if (reduce) { score.textContent = '56.1%'; return; }
    const t0 = performance.now();
    (function tick(t) {
      const k = Math.min(1, (t - t0) / 1300);
      score.textContent = `${(56.1 * k).toFixed(1)}%`;
      if (k < 1) requestAnimationFrame(tick);
    })(t0);
  }, 300));
}

// ------------------------------------------------------------ auth pages
function fieldErrors(form, fields) {
  form.querySelectorAll('.field').forEach(f => { f.classList.remove('invalid'); const e = f.querySelector('.field-error'); if (e) e.remove(); });
  Object.entries(fields || {}).forEach(([name, msg]) => {
    const input = form.querySelector(`[name="${name}"]`);
    if (!input) return;
    const f = input.closest('.field'); f.classList.add('invalid');
    f.insertAdjacentHTML('beforeend', `<div class="field-error">${esc(msg)}</div>`);
    input.setAttribute('aria-invalid', 'true');
  });
}

function afterLogin(user) {
  state.user = user; renderNav();
  const next = sessionStorage.getItem('afterLogin'); sessionStorage.removeItem('afterLogin');
  go(next && next !== '#/login' ? next : '#/dashboard');
}

function loginPage() {
  setTitle('Log in');
  main.innerHTML = `
  <div class="auth panel">
    <h1>Log in</h1>
    <form id="f" novalidate>
      <div id="err"></div>
      <div class="field"><label for="email">Email address</label><input id="email" name="email" type="email" autocomplete="email" required></div>
      <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required></div>
      <button class="btn-primary" style="width:100%">Log in</button>
    </form>
    <p class="small muted" style="margin-top:16px">New here? <a href="#/register">Create an account</a></p>
  </div>`;
  const f = document.getElementById('f');
  f.onsubmit = async e => {
    e.preventDefault();
    const btn = f.querySelector('button'); btn.disabled = true;
    try {
      const { user } = await api('/auth/login', { method: 'POST', body: { email: f.email.value, password: f.password.value } });
      toast(`Welcome back, ${user.fullName.split(' ')[0]}.`);
      afterLogin(user);
    } catch (err) {
      document.getElementById('err').innerHTML = `<div class="form-error">${esc(err.message)}</div>`;
      btn.disabled = false;
    }
  };
  f.email.focus();
}

const PW_RULES = [['len', 'At least 8 characters', p => p.length >= 8], ['let', 'A letter', p => /[A-Za-z]/.test(p)], ['num', 'A number', p => /\d/.test(p)]];

function registerPage() {
  setTitle('Create account');
  main.innerHTML = `
  <div class="auth panel">
    <h1>Create your account</h1>
    <p class="muted small">Your documents and reports are private to your account.</p>
    <form id="f" novalidate>
      <div id="err"></div>
      <div class="field"><label for="fullName">Full name</label><input id="fullName" name="fullName" type="text" autocomplete="name" maxlength="100" required></div>
      <div class="field"><label for="email">Email address</label><input id="email" name="email" type="email" autocomplete="email" required></div>
      <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="new-password" maxlength="128" required aria-describedby="pwRules">
        <ul class="pw-rules" id="pwRules">${PW_RULES.map(r => `<li data-r="${r[0]}">${r[1]}</li>`).join('')}</ul></div>
      <div class="field"><label for="confirm">Confirm password</label><input id="confirm" name="confirm" type="password" autocomplete="new-password" required></div>
      <button class="btn-primary" style="width:100%">Create account</button>
    </form>
    <p class="small muted" style="margin-top:16px">Already registered? <a href="#/login">Log in</a></p>
  </div>`;
  const f = document.getElementById('f');
  f.password.oninput = () => PW_RULES.forEach(([k, , test]) => f.querySelector(`[data-r="${k}"]`).classList.toggle('met', test(f.password.value)));
  f.onsubmit = async e => {
    e.preventDefault();
    const errs = {};
    if (f.fullName.value.trim().length < 2) errs.fullName = 'Enter your full name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email.value.trim())) errs.email = 'Enter a valid email address.';
    const failed = PW_RULES.filter(r => !r[2](f.password.value)).map(r => r[1].toLowerCase());
    if (failed.length) errs.password = `Password needs ${failed.join(', ')}.`;
    if (f.confirm.value !== f.password.value) errs.confirm = 'The two passwords do not match.';
    fieldErrors(f, errs);
    if (Object.keys(errs).length) { f.querySelector('[aria-invalid="true"]').focus(); return; }
    const btn = f.querySelector('button'); btn.disabled = true;
    try {
      const { user } = await api('/auth/register', { method: 'POST', body: { fullName: f.fullName.value, email: f.email.value, password: f.password.value } });
      toast('Your account is ready.');
      afterLogin(user);
    } catch (err) {
      fieldErrors(f, err.data && err.data.fields);
      document.getElementById('err').innerHTML = `<div class="form-error">${esc(err.message)}</div>`;
      btn.disabled = false;
    }
  };
  f.fullName.focus();
}

// ------------------------------------------------------------ dashboard
async function dashboard() {
  setTitle('Dashboard');
  const [stats, recent] = await Promise.all([api('/documents/stats'), api('/documents?pageSize=5')]);
  main.innerHTML = `
  <div class="spread">
    <div><h1>Hello, ${esc(state.user.fullName.split(' ')[0])}</h1><p class="muted" style="margin:0">Your private workspace. Only you can see these documents.</p></div>
    <a class="btn btn-primary" href="#/submit">Check a document</a>
  </div>
  <div class="tiles">
    <a class="tile" href="#/documents"><b>${stats.total}</b><span>Documents</span></a>
    <a class="tile" href="#/documents?status=completed"><b>${stats.completed}</b><span>Completed</span></a>
    <a class="tile" href="#/documents?status=processing"><b>${stats.pending + stats.processing}</b><span>Waiting or processing</span></a>
    <a class="tile" href="#/documents?status=failed"><b>${stats.failed}</b><span>Failed</span></a>
    <div class="tile"><b>${stats.avg_similarity === null ? '—' : pct(stats.avg_similarity)}</b><span>Average similarity</span></div>
  </div>
  <h2 style="margin-top:40px">Recent submissions</h2>
  ${recent.items.length ? docTable(recent.items) + '<p style="margin-top:16px"><a href="#/documents">See all documents</a></p>'
    : '<div class="empty"><h3>No documents yet</h3><p class="muted">Upload a PDF or Word file, or paste text, to get your first report.</p><a class="btn btn-primary" href="#/submit">Check a document</a></div>'}`;
  if (stats.pending + stats.processing > 0) pollTimer = setTimeout(() => location.hash.startsWith('#/dashboard') && render(), 4000);
}

function docTable(items, admin) {
  return `<table class="table"><thead><tr><th>Title</th>${admin ? '<th>Owner</th>' : ''}<th>Submitted</th><th>Status</th><th>Similarity</th><th>Report</th></tr></thead><tbody>
  ${items.map(d => `<tr>
    <td class="title">${admin ? `<strong>${esc(d.title)}</strong>` : `<a href="#/report/${d.id}">${esc(d.title)}</a>`}<div class="ref">${esc(d.report_ref)}</div></td>
    ${admin ? `<td data-label="Owner">${esc(d.owner_name)}<div class="small muted">${esc(d.owner_email)}</div></td>` : ''}
    <td data-label="Submitted">${fmtDate(d.created_at)}</td>
    <td data-label="Status">${statusBadge(d.status)}</td>
    <td data-label="Similarity"><span class="pct">${d.status === 'completed' ? pct(d.similarity) : '—'}</span></td>
    <td data-label="Report">${admin ? '<span class="small muted">Owner only</span>' : `<a href="#/report/${d.id}">${d.status === 'completed' ? 'Open report' : 'View status'}</a>`}</td>
  </tr>`).join('')}</tbody></table>`;
}

// ------------------------------------------------------------ submit
function submitPage() {
  setTitle('Check a document');
  main.innerHTML = `
  <div class="spread"><div><h1>Check a document</h1><p class="muted" style="margin:0">Your text is compared with the TimCheck <a href="#/sources">sample collection</a>.</p></div></div>
  <div class="panel" style="max-width:780px">
    <div class="tabs" role="tablist">
      <button role="tab" aria-selected="true" data-tab="file" id="tab-file">Upload a file</button>
      <button role="tab" aria-selected="false" data-tab="text" id="tab-text">Paste text</button>
    </div>
    <form id="f" novalidate>
      <div id="err"></div>
      <div class="field"><label for="title">Document title</label><input id="title" name="title" type="text" maxlength="200" placeholder="For example: Week 4 reflection essay"><div class="hint">Leave empty to use the file name.</div></div>
      <div data-pane="file">
        <input type="file" id="file" accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document" hidden>
        <div class="drop" id="drop" tabindex="0" role="button" aria-describedby="dropHint">
          <strong id="dropLabel">Choose a PDF or Word file</strong>
          <span class="muted small" id="dropHint">or drag it here. PDF and .docx up to ${MAX_UPLOAD_MB} MB. Scanned PDFs without text cannot be read.</span>
        </div>
      </div>
      <div data-pane="text" hidden>
        <div class="field"><label for="text">Text to check</label><textarea id="text" name="text" maxlength="200000" placeholder="Paste at least 20 words."></textarea><div class="counter" id="count">0 words</div></div>
      </div>
      <div class="progress" id="prog" hidden><i></i></div>
      <div class="row" style="margin-top:20px"><button class="btn-primary" id="go">Start check</button><span class="small muted">Results usually appear within a few seconds.</span></div>
    </form>
  </div>`;
  let mode = 'file', file = null;
  const f = document.getElementById('f');
  const drop = document.getElementById('drop'), input = document.getElementById('file');
  main.querySelectorAll('[role=tab]').forEach(t => t.onclick = () => {
    mode = t.dataset.tab;
    main.querySelectorAll('[role=tab]').forEach(x => x.setAttribute('aria-selected', x === t));
    main.querySelectorAll('[data-pane]').forEach(p => { p.hidden = p.dataset.pane !== mode; });
  });
  const pick = fl => {
    const err = document.getElementById('err'); err.innerHTML = '';
    if (!fl) return;
    if (!/\.(pdf|docx)$/i.test(fl.name)) { err.innerHTML = `<div class="form-error">${/\.doc$/i.test(fl.name) ? 'Old .doc files are not supported. Save it as .docx or PDF first.' : 'Choose a PDF or .docx file.'}</div>`; return; }
    if (fl.size > MAX_UPLOAD_MB * 1048576) { err.innerHTML = `<div class="form-error">This file is ${sizeLabel(fl.size)}. The limit is ${MAX_UPLOAD_MB} MB.</div>`; return; }
    file = fl;
    document.getElementById('dropLabel').textContent = `${fl.name} (${sizeLabel(fl.size)})`;
  };
  drop.onclick = () => input.click();
  drop.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } };
  input.onchange = () => pick(input.files[0]);
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => pick(e.dataTransfer.files[0]));
  const ta = document.getElementById('text');
  ta.oninput = () => { const n = (ta.value.match(/[\p{L}\p{N}]+/gu) || []).length; document.getElementById('count').textContent = `${n.toLocaleString()} words`; };

  f.onsubmit = e => {
    e.preventDefault();
    const err = document.getElementById('err'); err.innerHTML = '';
    const fd = new FormData();
    fd.append('title', f.title.value);
    if (mode === 'file') {
      if (!file) { err.innerHTML = '<div class="form-error">Choose a file first.</div>'; return; }
      fd.append('file', file);
    } else {
      const n = (ta.value.match(/[\p{L}\p{N}]+/gu) || []).length;
      if (n < 20) { err.innerHTML = '<div class="form-error">Paste at least 20 words.</div>'; return; }
      fd.append('text', ta.value);
    }
    const btn = document.getElementById('go'); btn.disabled = true; btn.textContent = 'Uploading…';
    const prog = document.getElementById('prog'); prog.hidden = false;
    // XMLHttpRequest is used here because it reports upload progress.
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/documents');
    xhr.setRequestHeader('X-Requested-With', 'TimCheck');
    xhr.upload.onprogress = ev => { if (ev.lengthComputable) prog.firstElementChild.style.width = `${(ev.loaded / ev.total) * 100}%`; };
    xhr.onload = () => {
      let data = {}; try { data = JSON.parse(xhr.responseText); } catch { /* ignore */ }
      if (xhr.status === 201) { toast('Submitted. Checking now.'); go(`#/report/${data.id}`); return; }
      if (xhr.status === 401) { state.user = null; renderNav(); go('#/login'); return; }
      err.innerHTML = `<div class="form-error">${esc(data.error || 'Upload failed. Please try again.')}</div>`;
      btn.disabled = false; btn.textContent = 'Start check'; prog.hidden = true;
    };
    xhr.onerror = () => { err.innerHTML = '<div class="form-error">Network error. Check your connection and try again.</div>'; btn.disabled = false; btn.textContent = 'Start check'; prog.hidden = true; };
    xhr.send(fd);
  };
}

// ------------------------------------------------------------ documents list
async function documentsPage(_, qs, admin = false) {
  setTitle(admin ? 'All submissions' : 'My documents');
  const params = new URLSearchParams();
  ['q', 'status', 'from', 'to', 'sort', 'page', 'user'].forEach(k => { if (qs.get(k)) params.set(k, qs.get(k)); });
  params.set('pageSize', '20');
  const data = await api((admin ? '/admin/documents?' : '/documents?') + params);
  const pages = Math.max(1, Math.ceil(data.total / data.pageSize));
  const base = admin ? '#/admin' : '#/documents';
  const link = page => { const p = new URLSearchParams(qs); p.set('page', page); return `${base}?${p}`; };
  const filtering = ['q', 'status', 'from', 'to', 'user'].some(k => qs.get(k));
  const listHtml = `
  <form class="filters" id="filters" role="search">
    <div><label for="q">Search title or reference</label><input id="q" name="q" type="search" value="${esc(qs.get('q') || '')}"></div>
    ${admin ? `<div><label for="user">User name or email</label><input id="user" name="user" type="search" value="${esc(qs.get('user') || '')}"></div>` : ''}
    <div><label for="status">Status</label><select id="status" name="status">
      ${['', 'pending', 'processing', 'completed', 'failed'].map(s => `<option value="${s}" ${qs.get('status') === s ? 'selected' : ''}>${s ? s[0].toUpperCase() + s.slice(1) : 'Any status'}</option>`).join('')}
    </select></div>
    <div><label for="from">From</label><input id="from" name="from" type="date" value="${esc(qs.get('from') || '')}"></div>
    <div><label for="to">To</label><input id="to" name="to" type="date" value="${esc(qs.get('to') || '')}"></div>
    ${admin ? '' : `<div><label for="sort">Sort</label><select id="sort" name="sort">
      ${[['newest', 'Newest first'], ['oldest', 'Oldest first'], ['similarity', 'Highest similarity'], ['title', 'Title A–Z']].map(([v, t]) => `<option value="${v}" ${(qs.get('sort') || 'newest') === v ? 'selected' : ''}>${t}</option>`).join('')}
    </select></div>`}
    <div class="row"><button class="btn-primary">Apply</button>${filtering ? `<a class="btn" href="${base}">Clear</a>` : ''}</div>
  </form>
  ${data.items.length ? docTable(data.items, admin) : `<div class="empty"><h3>${filtering ? 'No documents match these filters' : 'No documents yet'}</h3>${filtering ? `<p><a href="${base}">Clear the filters</a></p>` : '<p><a class="btn btn-primary" href="#/submit">Check a document</a></p>'}</div>`}
  <div class="pager">
    <span class="small muted">${data.total.toLocaleString()} document${data.total === 1 ? '' : 's'}. Page ${data.page} of ${pages}.</span>
    <span class="row">${data.page > 1 ? `<a class="btn btn-sm" href="${link(data.page - 1)}">Previous</a>` : ''}${data.page < pages ? `<a class="btn btn-sm" href="${link(data.page + 1)}">Next</a>` : ''}</span>
  </div>`;
  if (admin) return listHtml;
  main.innerHTML = `<div class="spread"><h1>My documents</h1><a class="btn btn-primary" href="#/submit">Check a document</a></div>${listHtml}`;
  wireFilters(base);
  if (data.items.some(d => d.status === 'pending' || d.status === 'processing')) {
    pollTimer = setTimeout(() => location.hash.startsWith('#/documents') && render(), 4000);
  }
}

function wireFilters(base) {
  const form = document.getElementById('filters');
  form.onsubmit = e => {
    e.preventDefault();
    const p = new URLSearchParams();
    new FormData(form).forEach((v, k) => { if (v) p.set(k, v); });
    go(`${base}?${p}`);
  };
}

// ------------------------------------------------------------ report
async function reportPage([id]) {
  const data = await api(`/documents/${encodeURIComponent(id)}`);
  const d = data.document;
  setTitle(d.title);
  const header = `<p class="no-print"><a href="#/documents">My documents</a></p>`;
  if (d.status === 'pending' || d.status === 'processing') {
    main.innerHTML = `${header}<div class="panel waiting"><div class="spinner" aria-hidden="true"></div>
      <h1 style="font-size:1.6rem">${esc(d.title)}</h1>
      <p>${statusBadge(d.status)}</p>
      <p class="muted">${d.status === 'pending' ? 'Your document is in the queue.' : 'Reading the text and comparing it with the sample collection.'} This page updates by itself.</p>
      <p class="small muted">Reference ${esc(d.report_ref)}. Submitted ${fmtDate(d.created_at)}.</p></div>`;
    pollTimer = setTimeout(() => location.hash === `#/report/${id}` && render(), 2000);
    return;
  }
  if (d.status === 'failed') {
    main.innerHTML = `${header}<div class="panel"><h1>${esc(d.title)}</h1><p>${statusBadge('failed')}</p>
      <div class="form-error">${esc(d.error_message || 'The document could not be processed.')}</div>
      <div class="row"><button class="btn-primary" id="retry">Try again</button><a class="btn" href="#/submit">Submit a different file</a><button class="btn-danger" id="del">Delete</button></div></div>`;
    document.getElementById('retry').onclick = async () => { await api(`/documents/${id}/retry`, { method: 'POST' }); toast('Queued again.'); render(); };
    document.getElementById('del').onclick = () => deleteDoc(id);
    return;
  }

  // Build highlighted text from character offsets.
  const idx = new Map(data.sources.map((s, i) => [s.source_id, i]));
  const text = d.extracted_text || '';
  let html = '', pos = 0;
  data.matches.forEach((m, i) => {
    html += esc(text.slice(pos, m.char_start));
    const si = idx.get(m.source_id);
    html += `<mark class="m c${si % 8}" data-i="${i}" tabindex="0" title="Matches source ${si + 1}">${esc(text.slice(m.char_start, m.char_end))}<sup>${si + 1}</sup></mark>`;
    pos = m.char_end;
  });
  html += esc(text.slice(pos));
  const wm = Array.from({ length: 22 }, () => `<div>${WATERMARK}&nbsp;&nbsp;&nbsp;${WATERMARK}</div>`).join('');

  main.innerHTML = `${header}
  <div class="report-grid">
    <article class="report-paper" aria-label="Similarity report">
      <div class="watermark" aria-hidden="true">${wm}</div>
      <div class="report-head">
        <div>
          <h1>${esc(d.title)}</h1>
          <dl class="meta">
            <dt>Report reference</dt><dd>${esc(d.report_ref)}</dd>
            <dt>Submitted</dt><dd>${fmtDate(d.created_at)}</dd>
            <dt>Words checked</dt><dd>${Number(d.word_count).toLocaleString()}</dd>
            <dt>Matched words</dt><dd>${Number(d.matched_words).toLocaleString()}</dd>
            <dt>Matched passages</dt><dd>${data.matches.length}</dd>
          </dl>
        </div>
        <div class="score"><b>${pct(d.similarity)}</b><span>similarity estimate<br>(demo calculation)</span></div>
      </div>
      <div style="padding:20px 24px 0"><div class="disclaimer"><strong>Educational demonstration, not a Turnitin report.</strong> TimCheck compared this text only with its own ${'<a href="#/sources">sample collection</a>'}. It is not connected to Turnitin or any other database.${d.error_message ? ` ${esc(d.error_message)}` : ''}</div></div>
      <div class="report-text" id="rt">${html || '<span class="muted">No text.</span>'}</div>
    </article>
    <aside class="report-side stack">
      <div class="panel actions">
        <div class="row"><a class="btn btn-primary" href="/api/documents/${d.id}/report.pdf">Download PDF report</a><button id="print">Print</button></div>
        <div class="row" style="margin-top:12px"><button class="btn-sm btn-danger" id="del">Delete document</button></div>
      </div>
      <div class="panel">
        <h2 style="font-size:1.2rem">Matched sample sources</h2>
        ${data.sources.length ? `<ul class="sources-list">${data.sources.map((s, i) => `
          <li class="c${i % 8}"><span class="chip">${i + 1}</span>
            <div><div class="t"><a href="#/sources/${s.source_id}">${esc(s.title)}</a></div><div class="small muted">${s.words} matched words</div></div>
            <span class="p">${pct(s.percent)}</span></li>`).join('')}</ul>`
          : '<p class="muted">No passages matched the sample collection.</p>'}
        <div id="pop" aria-live="polite"></div>
      </div>
      <div class="panel small">
        <h3>Reading this number</h3>
        <p>${pct(d.similarity)} of the words are inside passages of 5 or more words that also appear in a sample source. Quotes and references count as matches too, so a high number is not proof of plagiarism, and a low number is not proof of originality.</p>
        <p style="margin:0">Text fingerprint (SHA-256): <span class="ref" style="word-break:break-all">${esc(d.text_sha256)}</span></p>
      </div>
    </aside>
  </div>`;
  document.getElementById('print').onclick = () => window.print();
  document.getElementById('del').onclick = () => deleteDoc(id);
  const showPassage = mk => {
    main.querySelectorAll('mark.active').forEach(x => x.classList.remove('active'));
    mk.classList.add('active');
    const m = data.matches[mk.dataset.i]; const si = idx.get(m.source_id); const s = data.sources[si];
    document.getElementById('pop').innerHTML = `<div class="passage-pop c${si % 8}"><span class="chip">${si + 1}</span> <strong>${m.word_count} words</strong> match <em>${esc(s.title)}</em>:<p style="margin:8px 0 0"><q>${esc(m.source_excerpt)}</q></p></div>`;
  };
  document.getElementById('rt').addEventListener('click', e => { const mk = e.target.closest('mark.m'); if (mk) showPassage(mk); });
  document.getElementById('rt').addEventListener('keydown', e => { const mk = e.target.closest('mark.m'); if (mk && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); showPassage(mk); } });
}

async function deleteDoc(id) {
  if (!confirm('Delete this document and its report? This cannot be undone.')) return;
  await api(`/documents/${id}`, { method: 'DELETE' });
  toast('Document deleted.');
  go('#/documents');
}

// ------------------------------------------------------------ verify
async function verifyPage([ref]) {
  setTitle('Verify a report');
  main.innerHTML = `
  <div class="prose">
    <h1>Verify a TimCheck report</h1>
    <p>Reports can be edited after download. A PDF can be changed to show a lower number or a different title. Enter the reference printed on a TimCheck report to see the values that are stored on this server.</p>
    <form id="vf" class="row" style="align-items:flex-end">
      <div style="flex:1;min-width:240px"><label for="ref">Report reference</label><input id="ref" name="ref" type="text" placeholder="TC-20261023-1A2B3C4D5E" value="${esc(ref || '')}" autocapitalize="characters"></div>
      <button class="btn-primary">Check reference</button>
    </form>
    <div id="vr" style="margin-top:24px"></div>
    <div class="callout small">This page can only confirm TimCheck reports. It cannot confirm reports from Turnitin or any other service. To check those, ask your institution or use the service's own verification route.</div>
  </div>`;
  const vf = document.getElementById('vf');
  const run = async r => {
    const out = document.getElementById('vr');
    out.innerHTML = '<p class="muted">Checking…</p>';
    try {
      const { report } = await api(`/verify/${encodeURIComponent(r.trim())}`);
      out.innerHTML = `<div class="panel">
        <p>${statusBadge('completed')} This reference exists in TimCheck. Compare every value below with the report you were given. If any value is different, the report has been changed.</p>
        <dl class="meta">
          <dt>Reference</dt><dd>${esc(report.report_ref)}</dd>
          <dt>Submitted</dt><dd>${fmtDate(report.created_at)}</dd>
          <dt>Words checked</dt><dd>${Number(report.word_count).toLocaleString()}</dd>
          <dt>Matched words</dt><dd>${Number(report.matched_words).toLocaleString()}</dd>
          <dt>Similarity</dt><dd>${pct(report.similarity)}</dd>
          <dt>Text fingerprint</dt><dd class="ref" style="word-break:break-all">${esc(report.text_sha256)}</dd>
        </dl>
        <p class="small muted" style="margin:12px 0 0">The title and text are private to the owner, so they are not shown here.</p></div>`;
    } catch (e) {
      out.innerHTML = `<div class="form-error">${esc(e.message)} A missing or unknown reference is a strong sign that a report is not genuine.</div>`;
    }
  };
  vf.onsubmit = e => { e.preventDefault(); if (vf.ref.value.trim()) { history.replaceState(null, '', `#/verify/${encodeURIComponent(vf.ref.value.trim())}`); run(vf.ref.value); } };
  if (ref) run(decodeURIComponent(ref));
}

// ------------------------------------------------------------ sources
async function sourcesPage([id]) {
  if (id) {
    const s = await api(`/sources/${encodeURIComponent(id)}`);
    setTitle(s.title);
    main.innerHTML = `<p><a href="#/sources">Sample collection</a></p><article class="panel prose"><h1>${esc(s.title)}</h1>
      <p class="small muted">${esc(s.author || '')}${s.origin ? ` — ${esc(s.origin)}` : ''}. ${s.word_count} words.</p>
      <div style="font-family:var(--serif);white-space:pre-wrap;line-height:1.75">${esc(s.body)}</div></article>`;
    return;
  }
  setTitle('Sample collection');
  const { items } = await api('/sources');
  main.innerHTML = `<div class="prose"><h1>The sample collection</h1>
    <p>Every submission is compared only with these ${items.length} documents. They were written for this demonstration. Turnitin and other commercial services compare against billions of web pages, publications and past student papers, which TimCheck does not have.</p>
    <p class="small muted">The site owner can add more sources with <code>npm run add-sources -- ./folder</code>.</p></div>
    <table class="table" style="margin-top:16px"><thead><tr><th>Title</th><th>Origin</th><th>Words</th></tr></thead><tbody>
    ${items.map(s => `<tr><td class="title"><a href="#/sources/${s.id}">${esc(s.title)}</a></td><td data-label="Origin">${esc(s.origin || '')}</td><td data-label="Words">${s.word_count}</td></tr>`).join('')}
    </tbody></table>`;
}

// ------------------------------------------------------------ admin
async function adminPage(_, qs) {
  if (state.user.role !== 'admin') { main.innerHTML = '<div class="form-error">Admins only.</div>'; return; }
  const stats = await api('/admin/stats');
  const list = await documentsPage(_, qs, true);
  setTitle('Admin');
  main.innerHTML = `<div class="spread"><div><h1>All submissions</h1><p class="muted" style="margin:0">Admins see document details, not document text. Reports stay private to their owners.</p></div></div>
  <div class="tiles" style="margin-bottom:24px">
    <div class="tile"><b>${stats.users}</b><span>Users</span></div>
    <div class="tile"><b>${stats.documents.toLocaleString()}</b><span>Documents</span></div>
    <div class="tile"><b>${stats.pending + stats.processing}</b><span>In the queue</span></div>
    <div class="tile"><b>${stats.failed}</b><span>Failed</span></div>
    <div class="tile"><b>${stats.sources}</b><span>Sample sources</span></div>
  </div>${list}`;
  wireFilters('#/admin');
}

// ------------------------------------------------------------ learn
function learnPage() {
  setTitle('Learn');
  main.innerHTML = `
  <div class="learn-layout">
    <nav class="toc" aria-label="On this page"><ol>
      <li><a href="#/learn" data-to="learn-how">How TimCheck works</a></li>
      <li><a href="#/learn" data-to="learn-fake">How fake checker sites imitate real services</a></li>
      <li><a href="#/learn" data-to="learn-scores">How invented scores and edited PDFs mislead students</a></li>
      <li><a href="#/learn" data-to="learn-verify">Telling a genuine report from an unverified one</a></li>
      <li><a href="#/learn" data-to="learn-percent">Why a percentage is not proof of plagiarism</a></li>
      <li><a href="#/learn" data-to="learn-limits">Limits of this demonstration</a></li>
    </ol></nav>
    <article class="prose">
      <h1>How similarity checking works, and how it is faked</h1>
      <p>This page explains what a similarity report really measures, how dishonest websites and edited files copy the look of a report, and how to protect yourself.</p>

      <h2 id="learn-how">How TimCheck works</h2>
      <ol>
        <li><strong>Read the text.</strong> PDF and Word files are turned into plain text. Pasted text is used as it is.</li>
        <li><strong>Split it into words.</strong> Capital letters and punctuation are ignored, so “Hand hygiene,” and “hand hygiene” are the same.</li>
        <li><strong>Make five-word pieces.</strong> “hand hygiene remains the single” is one piece, “hygiene remains the single most” is the next, and so on.</li>
        <li><strong>Look them up.</strong> Every piece of every sample source is stored in a database index. All pieces of your document are looked up in one query, and each hit is checked word by word.</li>
        <li><strong>Join hits into passages.</strong> Hits that continue in the same order in both texts become one highlighted passage.</li>
        <li><strong>Count each word once.</strong> If two sources match the same words, the longer passage wins, so nothing is counted twice.</li>
        <li><strong>Calculate.</strong> Similarity = matched words ÷ total words × 100. The same text always gives the same number.</li>
      </ol>
      <p>Commercial checkers use similar ideas but much larger collections, more careful handling of quotes and references, and methods that can catch some light rewording. TimCheck finds exact runs of five or more words only.</p>

      <h2 id="learn-fake">How fake checker sites imitate real services</h2>
      <p>Some websites sell “official” plagiarism reports or “guaranteed 0% similarity” services. Common tricks include:</p>
      <ul>
        <li><strong>Borrowed names and logos.</strong> A name that contains or sounds like a well-known brand, plus a copied logo and colours, so the site looks official.</li>
        <li><strong>Copied report layouts.</strong> Screenshots or templates of real reports, with a new number typed in.</li>
        <li><strong>No real checking.</strong> The site shows a progress bar and then a random or chosen score. Sometimes it never reads the file at all.</li>
        <li><strong>Collecting papers.</strong> Some sites keep and resell uploaded essays, which can later make the original author look like the copier.</li>
        <li><strong>Pressure to pay.</strong> A low score is shown only after payment, or a high score is shown to sell a “rewriting” service.</li>
      </ul>
      <div class="callout">This is why TimCheck uses its own name, puts a watermark on every report, and says on every page that it is not connected to Turnitin.</div>

      <h2 id="learn-scores">How invented scores and edited PDFs mislead students</h2>
      <p>A PDF is easy to change. With common editing tools, anyone can change the percentage, the title, the date or the student name, or delete the highlighted pages. The result can look exactly like a real report.</p>
      <div class="fake-vs-real">
        <div class="mini-report flag"><b class="big">3%</b>Edited PDF given to a student. Reference TC-20261023-… is printed on it. The highlights page has been removed.</div>
        <div class="mini-report"><b class="big">38.4%</b>Value stored on the TimCheck server for the same reference, shown on the verification page.</div>
      </div>
      <p>Students are harmed in several ways. They may submit work believing it is safe, pay for a service that did nothing, or be accused of misconduct when the institution runs its own check and gets a very different result. Presenting a falsified report to a school is itself academic misconduct and can have serious consequences.</p>

      <h2 id="learn-verify">Telling a genuine report from an unverified one</h2>
      <table class="compare">
        <thead><tr><th>Check</th><th>Genuine report</th><th>Warning sign</th></tr></thead>
        <tbody>
          <tr><td>Where it came from</td><td>Your institution's learning system, or a service your teacher named</td><td>A website found through an advert, a social media message, or a seller</td></tr>
          <tr><td>Verification</td><td>Can be confirmed with the issuer, or by the teacher inside their own account</td><td>No reference, or a reference the issuer does not recognise</td></tr>
          <tr><td>Numbers</td><td>Percentages add up and match the highlighted text</td><td>Round or very low numbers with few or no highlights</td></tr>
          <tr><td>File</td><td>Downloaded by you, directly from the service</td><td>Sent to you as an attachment or screenshot by someone else</td></tr>
          <tr><td>Promises</td><td>Explains that the number needs human review</td><td>Guarantees “0%” or “undetectable” results</td></tr>
        </tbody>
      </table>
      <p>For TimCheck reports, use the <a href="#/verify">verification page</a>. For any other service, ask the issuer directly. A screenshot or PDF alone is never proof.</p>

      <h2 id="learn-percent">Why a percentage is not proof of plagiarism</h2>
      <ul>
        <li><strong>Correct quotes match.</strong> A properly quoted and referenced sentence is still the same words as its source.</li>
        <li><strong>Common phrases match.</strong> Technical terms, standard definitions and set phrases (“evidence-based practice is”) appear in many texts.</li>
        <li><strong>Your own earlier work matches.</strong> Reusing your own draft or an earlier assignment can raise the number.</li>
        <li><strong>Reference lists match.</strong> Citations often appear in exactly the same form in other papers.</li>
        <li><strong>A low number can hide problems.</strong> Heavy paraphrasing, translation, or work written by someone else may show no matches at all.</li>
      </ul>
      <p>A similarity report is a starting point for a human reader. Teachers look at <em>which</em> passages match and <em>why</em>, then decide whether there is a problem. No single percentage is a pass or fail line.</p>

      <h2 id="learn-limits">Limits of this demonstration</h2>
      <ul>
        <li>The collection has only a small number of sample texts, so most real writing will show 0%.</li>
        <li>Only exact runs of five or more words are found. Light rewording is not detected.</li>
        <li>Quotes and references are not excluded automatically.</li>
        <li>Scanned PDFs that contain images instead of text cannot be read. Old .doc files are not supported.</li>
        <li>Documents longer than the configured word limit are checked only up to that limit, and the report says so.</li>
      </ul>
    </article>
  </div>`;
  // In-page links (the address bar hash is used by the router, so scroll manually).
  main.querySelectorAll('.toc a[data-to]').forEach(a => a.onclick = e => {
    e.preventDefault();
    const target = document.getElementById(a.dataset.to);
    target.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
    target.setAttribute('tabindex', '-1'); target.focus({ preventScroll: true });
  });
}
