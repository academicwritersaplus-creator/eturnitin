'use strict';
const db = require('./db');

// Loads the logged-in user from the database on every protected request,
// so a deleted account or changed role takes effect immediately.
async function requireAuth(req, res, next) {
  try {
    if (!req.session || !req.session.userId) return res.status(401).json({ error: 'Please log in.' });
    const { rows } = await db.query('SELECT id, full_name, email, role FROM users WHERE id = $1', [req.session.userId]);
    if (!rows[0]) {
      req.session.destroy(() => {});
      return res.status(401).json({ error: 'Please log in.' });
    }
    req.user = rows[0];
    next();
  } catch (e) { next(e); }
}

function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') return res.status(403).json({ error: 'Admins only.' });
  next();
}

// CSRF protection: browsers will not let another website add a custom header
// to a cross-site request without a CORS pre-flight (which we never allow).
function requireAppHeader(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('X-Requested-With') !== 'TimCheck') return res.status(403).json({ error: 'Missing request header.' });
  next();
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function asyncRoute(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

module.exports = { requireAuth, requireAdmin, requireAppHeader, UUID_RE, asyncRoute };
