'use strict';
const express = require('express');
const crypto = require('crypto');
const multer = require('multer');
const rateLimit = require('express-rate-limit');
const db = require('./db');
const config = require('./config');
const storage = require('./storage');
const { detectType } = require('./extract');
const { buildReportPdf } = require('./report-pdf');
const { requireAuth, UUID_RE, asyncRoute } = require('./middleware');

const router = express.Router();
router.use(requireAuth);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.maxUploadMb * 1024 * 1024, files: 1, fields: 5, fieldSize: config.maxPasteChars * 4 },
});

const uploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, limit: config.uploadsPerHour, standardHeaders: 'draft-7', legacyHeaders: false,
  keyGenerator: req => `u${req.user.id}`,
  message: { error: `Upload limit reached (${config.uploadsPerHour} per hour). Please try again later.` },
});

function makeReportRef() {
  const d = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  return `TC-${d}-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
}

function cleanTitle(t, fallback) {
  const s = String(t || '').replace(/[\u0000-\u001f]/g, ' ').trim().replace(/\s+/g, ' ');
  return (s || fallback || 'Untitled document').slice(0, 200);
}

// ------------------------------------------------------------- submit
router.post('/', uploadLimiter, (req, res, next) => {
  upload.single('file')(req, res, err => {
    if (!err) return next();
    if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: `File is too large. The limit is ${config.maxUploadMb} MB.` });
    if (err.code === 'LIMIT_FIELD_VALUE') return res.status(413).json({ error: `Pasted text is too long. The limit is ${config.maxPasteChars.toLocaleString()} characters.` });
    return res.status(400).json({ error: 'Upload failed: ' + err.message });
  });
}, asyncRoute(async (req, res) => {
  let buffer, type, filename = null;
  if (req.file) {
    filename = req.file.originalname.slice(0, 255);
    type = detectType(req.file.buffer, filename);
    if (!type) {
      const isDoc = /\.doc$/i.test(filename);
      return res.status(400).json({ error: isDoc
        ? 'Old .doc files are not supported. Please save the file as .docx or PDF and try again.'
        : 'Only PDF (.pdf) and Word (.docx) files are accepted, or paste your text.' });
    }
    buffer = req.file.buffer;
  } else {
    const text = String(req.body.text || '');
    if (!text.trim()) return res.status(400).json({ error: 'Choose a file or paste some text.' });
    if (text.length > config.maxPasteChars) return res.status(413).json({ error: `Pasted text is too long. The limit is ${config.maxPasteChars.toLocaleString()} characters.` });
    const words = text.match(/[\p{L}\p{N}]+/gu) || [];
    if (words.length < config.minWords) return res.status(400).json({ error: `Please paste at least ${config.minWords} words.` });
    buffer = Buffer.from(text, 'utf8');
    type = 'text';
  }

  const id = crypto.randomUUID();
  const ext = type === 'text' ? 'txt' : type;
  const key = `u${req.user.id}/${id}.${ext}`;
  const title = cleanTitle(req.body.title, filename ? filename.replace(/\.[^.]+$/, '') : 'Pasted text');

  await storage.save(key, buffer);
  try {
    await db.query(
      `INSERT INTO documents (id, user_id, title, input_type, original_filename, size_bytes, storage_key, report_ref)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [id, req.user.id, title, type, filename, buffer.length, key, makeReportRef()]);
  } catch (e) {
    await storage.remove(key).catch(() => {});
    throw e;
  }
  res.status(201).json({ id, status: 'pending' });
}));

// ------------------------------------------------------------- list
const SORTS = {
  newest: 'created_at DESC, id',
  oldest: 'created_at ASC, id',
  similarity: 'similarity DESC NULLS LAST, created_at DESC',
  title: 'title ASC, created_at DESC',
};

// Adds search/filter conditions. Values always go in as $n parameters,
// never pasted into the SQL, so search text cannot inject SQL.
function buildFilters(q, params) {
  const where = [];
  if (q.q) {
    params.push(`%${String(q.q).slice(0, 100).replace(/[\\%_]/g, m => '\\' + m)}%`);
    where.push(`(d.title ILIKE $${params.length} OR d.report_ref ILIKE $${params.length})`);
  }
  if (['pending', 'processing', 'completed', 'failed'].includes(q.status)) {
    params.push(q.status); where.push(`d.status = $${params.length}`);
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(q.from || '')) { params.push(q.from); where.push(`d.created_at >= $${params.length}::date`); }
  if (/^\d{4}-\d{2}-\d{2}$/.test(q.to || '')) { params.push(q.to); where.push(`d.created_at < ($${params.length}::date + 1)`); }
  return where;
}

function paging(q) {
  const pageSize = Math.min(Math.max(parseInt(q.pageSize, 10) || 20, 5), 100);
  const page = Math.max(parseInt(q.page, 10) || 1, 1);
  return { page, pageSize, offset: (page - 1) * pageSize };
}

router.get('/', asyncRoute(async (req, res) => {
  const params = [req.user.id];
  const where = ['d.user_id = $1', ...buildFilters(req.query, params)];
  const { page, pageSize, offset } = paging(req.query);
  const order = SORTS[req.query.sort] || SORTS.newest;
  const whereSql = where.join(' AND ');
  const [list, count] = await Promise.all([
    db.query(
      `SELECT d.id, d.title, d.input_type, d.original_filename, d.size_bytes, d.status, d.error_message,
              d.word_count, d.similarity, d.report_ref, d.created_at, d.completed_at
       FROM documents d WHERE ${whereSql} ORDER BY ${order} LIMIT ${pageSize} OFFSET ${offset}`, params),
    db.query(`SELECT count(*)::int AS n FROM documents d WHERE ${whereSql}`, params),
  ]);
  res.json({ items: list.rows, total: count.rows[0].n, page, pageSize });
}));

router.get('/stats', asyncRoute(async (req, res) => {
  const { rows } = await db.query(
    `SELECT count(*)::int AS total,
            count(*) FILTER (WHERE status = 'pending')::int    AS pending,
            count(*) FILTER (WHERE status = 'processing')::int AS processing,
            count(*) FILTER (WHERE status = 'completed')::int  AS completed,
            count(*) FILTER (WHERE status = 'failed')::int     AS failed,
            round(avg(similarity), 1) AS avg_similarity
     FROM documents WHERE user_id = $1`, [req.user.id]);
  res.json(rows[0]);
}));

// ------------------------------------------------------------- single
async function ownDocument(req, res, columns = 'd.*') {
  if (!UUID_RE.test(req.params.id)) { res.status(404).json({ error: 'Document not found.' }); return null; }
  // The user_id check is what stops anyone opening someone else's document.
  const { rows } = await db.query(`SELECT ${columns} FROM documents d WHERE d.id = $1 AND d.user_id = $2`,
    [req.params.id, req.user.id]);
  if (!rows[0]) { res.status(404).json({ error: 'Document not found.' }); return null; }
  return rows[0];
}

async function reportData(docId) {
  const [m, s] = await Promise.all([
    db.query(`SELECT source_id, char_start, char_end, word_count, source_excerpt
              FROM matches WHERE document_id = $1 ORDER BY char_start`, [docId]),
    db.query(`SELECT s.id AS source_id, s.title, s.author, s.origin, sum(m.word_count)::int AS words
              FROM matches m JOIN sources s ON s.id = m.source_id
              WHERE m.document_id = $1 GROUP BY s.id ORDER BY words DESC, s.id`, [docId]),
  ]);
  return { matches: m.rows, sources: s.rows };
}

router.get('/:id', asyncRoute(async (req, res) => {
  const doc = await ownDocument(req, res,
    `d.id, d.title, d.input_type, d.original_filename, d.size_bytes, d.status, d.error_message, d.word_count,
     d.matched_words, d.similarity, d.report_ref, d.text_sha256, d.created_at, d.started_at, d.completed_at,
     d.extracted_text`);
  if (!doc) return;
  const data = doc.status === 'completed' ? await reportData(doc.id) : { matches: [], sources: [] };
  data.sources.forEach(s => { s.percent = doc.word_count ? Math.round((s.words / doc.word_count) * 1000) / 10 : 0; });
  res.json({ document: doc, ...data });
}));

router.get('/:id/report.pdf', asyncRoute(async (req, res) => {
  const doc = await ownDocument(req, res);
  if (!doc) return;
  if (doc.status !== 'completed') return res.status(409).json({ error: 'The report is not ready yet.' });
  const { matches, sources } = await reportData(doc.id);
  sources.forEach(s => { s.percent = doc.word_count ? Math.round((s.words / doc.word_count) * 1000) / 10 : 0; });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="TimCheck-demo-report-${doc.report_ref}.pdf"`);
  res.setHeader('Cache-Control', 'private, no-store');
  buildReportPdf(doc, sources, matches, res);
}));

router.post('/:id/retry', asyncRoute(async (req, res) => {
  const doc = await ownDocument(req, res, 'd.id, d.status');
  if (!doc) return;
  if (doc.status !== 'failed') return res.status(409).json({ error: 'Only failed documents can be retried.' });
  await db.query(`UPDATE documents SET status = 'pending', attempts = 0, error_message = NULL WHERE id = $1`, [doc.id]);
  res.json({ ok: true });
}));

router.delete('/:id', asyncRoute(async (req, res) => {
  const doc = await ownDocument(req, res, 'd.id, d.storage_key');
  if (!doc) return;
  await db.query('DELETE FROM documents WHERE id = $1 AND user_id = $2', [doc.id, req.user.id]);
  await storage.remove(doc.storage_key).catch(e => console.warn('[storage] remove failed', e.message));
  res.json({ ok: true });
}));

module.exports = router;
module.exports.buildFilters = buildFilters;
module.exports.paging = paging;
module.exports.SORTS = SORTS;
